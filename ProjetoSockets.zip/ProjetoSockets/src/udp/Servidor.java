package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Servidor extends Thread{
    
    // Porta de comunicação
    private final int PORTA = 12345;
    
    public Servidor(){
        System.out.println("Servidor iniciado na porta " + PORTA);
    }
    
    @Override
    public void run(){
        try {
            //Criar novo SOCKET
            DatagramSocket srv = new DatagramSocket(PORTA);
            
            while(true){
                //  definir o buffer da mensagem
                byte[] buffer = new byte[256];
                
                DatagramPacket pct = new DatagramPacket(
                        buffer,
                        buffer.length
                );
                
                //  receber o pacote
                srv.receive(pct);
                    
                //  transformar o pct no tipo esperado
                String msg = new String(pct.getData()).trim();
                
                //  exibir a msg no servidor
                System.out.println("DE");
                System.out.println(pct.getAddress().getHostAddress());
                System.out.println("MSG");
                System.out.println(msg + "\n");
                
                
            }
            
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        new Servidor().start();
    }
}
