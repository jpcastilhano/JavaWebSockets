package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Cliente extends Thread{
    
    private final String HOST = "127.0.0.1";
    private final int PORTA = 12345;
    
    public void enviar(String msg) {
        try {
            //  converter a msg em byts
            byte[] buffer = msg.getBytes();
            
            DatagramPacket pct = new DatagramPacket(
                    buffer,
                    buffer.length,
                    InetAddress.getByName(HOST),
                    PORTA                    
            );
            
            //  enviar o pacote
            new DatagramSocket().send(pct);
            
            
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
        }
    }
    
}
