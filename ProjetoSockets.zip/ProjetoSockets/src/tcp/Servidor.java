package tcp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JTextArea;

public class Servidor extends Thread{
    
    private final int PORTA = 5000;
    private ObjectInputStream fluxo_entrada;
    private ObjectOutputStream fluxo_saida;
    private final JTextArea txt;
    
    public Servidor (JTextArea txt){
        this.txt = txt;
    }
    
    public void enviar (Mensagem msg){
        try{
            fluxo_saida.writeObject(msg);
            fluxo_saida.flush();
        } catch (Exception e){
            System.err.println("ERRO: " + e.getMessage());
        }
    }
    
    @Override
    public void run(){
        try {
            ServerSocket srv = new ServerSocket(PORTA);
            txt.append("Servidor iniciado\n");
            
            while(true){
                txt.append("Aguardando conexão...\n");
                Socket con = srv.accept();
                
                txt.append("Conexão de: " + con.getInetAddress().getHostAddress());
                
                fluxo_saida = new ObjectOutputStream(con.getOutputStream());
                fluxo_entrada = new ObjectInputStream(con.getInputStream());
                
                //Enviar msg para o cliente
                enviar(new Mensagem("INFORMAÇÃO", "Conexão realizada com sucesso"));
                
                Mensagem msg;
                do{
                    msg = (Mensagem)fluxo_entrada.readObject();
                    txt.append("\n\n" + msg.getTitulo());
                    txt.append("\n" + msg.getConteudo());
                } while (!msg.getTitulo().toUpperCase().equals("FIM"));
                
                fluxo_entrada.close();
                fluxo_saida.close();
                con.close();
            }
        } catch (Exception e) {
        }
    }
}
