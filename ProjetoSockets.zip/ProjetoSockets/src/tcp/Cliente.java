package tcp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JTextArea;


public class Cliente extends Thread{
   
    private final int PORTA = 5000;
    private final String URL = "127.0.0.1";
    private ObjectInputStream fluxo_entrada;
    private ObjectOutputStream fluxo_saida;
    private final JTextArea txt;
    
    public Cliente (JTextArea txt){
        this.txt = txt;
    }
    
    public void enviar (Mensagem msg){
        try {
            fluxo_saida.writeObject(msg);
            fluxo_saida.flush();
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
        }
    }
    
    @Override
    public void run() {
        try {
            Socket con = new Socket(URL, PORTA);
            fluxo_saida = new ObjectOutputStream(con.getOutputStream());
            fluxo_entrada = new ObjectInputStream(con.getInputStream());
            Mensagem msg;
            do {
                msg = (Mensagem) fluxo_entrada.readObject();
                txt.append("\n\n" + msg.getTitulo());
                txt.append("\n" + msg.getConteudo() + "\n");
            } while (!msg.getTitulo().toUpperCase().equals("FIM"));
            fluxo_entrada.close();
            fluxo_saida.close();
            con.close();
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
        }
    }
}
