package webserver;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class WebServer extends Thread {
    
    private final int PORTA = 80;
    
    public WebServer(){
        System.out.println("Servidor Web iniciado.");
    }
    
    @Override
    public void run(){
        try {
            ServerSocket srv = new ServerSocket(PORTA);
            while (true){
                Socket con = srv.accept();
                BufferedReader fluxo_entrada = new BufferedReader(
                    new InputStreamReader(con.getInputStream())
                );
                
                String requisicao = fluxo_entrada.readLine();
                System.out.println("REQUISIÇÃO");
                System.out.println(requisicao + "\n\n");
                
                StringBuilder resposta = new StringBuilder();
                resposta.append("<html>");
                resposta.append("<head>");
                resposta.append("<meta charset='utf-8' />");
                resposta.append("</head>");
                resposta.append("<body>");
                resposta.append("<h1>Alessandro Akira é a Juju do Pix</h1>");
                resposta.append("</body>");
                resposta.append("</html>");
                
                con.getOutputStream().write(
                    resposta.toString().getBytes()
                );
                fluxo_entrada.close();
                con.close();
            }
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        new WebServer().start();
    }
    
}
